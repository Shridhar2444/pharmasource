from django.contrib import admin
from home.models import donor1
from home.models import reciever1
# from home.models import signup1
# from home.models import login1
# Register your models here.
class donor_admin(admin.ModelAdmin):
 list_display=('Tabletname','Expiry', 'desc','Quantity')
admin.site.register(donor1,donor_admin)
admin.site.register(reciever1)
# admin.site.register(signup1)
# admin.site.register(login1)

